package kr.controller.pik;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import kr.dao.pik.BeerMapper;
import kr.entity.pik.BEER;
import kr.entity.pik.BEER2;


public class beerViewListController implements Controller {

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		System.out.println("beerViewList");
		List<BEER2> list;
		
		
		String name = request.getParameter("beer_name");
		int beer_from = Integer.parseInt(request.getParameter("beer_from"));
		int beer_aroma = Integer.parseInt(request.getParameter("beer_aroma"));		
		int beer_taste = Integer.parseInt(request.getParameter("beer_taste"));	
		if ( name == null) {
			BEER vo = new BEER(beer_from, beer_aroma, beer_taste);
			System.out.println(vo);
			System.out.println(beer_from + " / " + beer_aroma + " / " + beer_taste );
			
			BeerMapper dao = new BeerMapper();
			list = dao.viewList(vo);
		} else {
			BEER vo = new BEER(name, beer_from, beer_aroma, beer_taste);
			System.out.println(vo);
			System.out.println(name + " / " + beer_from + " / " + beer_aroma + " / " + beer_taste );
			
			BeerMapper dao = new BeerMapper();
			list = dao.viewList2(vo);
		}
		
		/*
		 vo.setBEER_NAME(name); vo.setFROM_SEQ(from_seq); vo.setAROMA_SEQ(AROMA_SEQ);
		 vo.setTASTE_SEQ(TASTE_SEQ);
		 */	
		
		
		Gson gson = new Gson();
		String json = gson.toJson(list);
		
		response.setContentType("text/json;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		out.println(json);
		
		return null;
	}

}
