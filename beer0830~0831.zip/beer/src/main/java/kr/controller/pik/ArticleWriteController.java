package kr.controller.pik;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.dao.pik.ArticleMapper;
import kr.entity.pik.Article;
import kr.entity.pik.Member;

public class ArticleWriteController implements Controller{

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		Member mvo = (Member)session.getAttribute("mvo");
		String b_title = request.getParameter("b_title");
		String b_content = request.getParameter("b_content");
		String b_file="null";
		String m_id=mvo.getM_id();
		
		System.out.println(mvo.getM_id());
		
		Article avo = new Article(b_title, b_content, b_file, m_id);
		
		System.out.println(avo.toString());
		
		ArticleMapper dao = new ArticleMapper();
		
		int seq = dao.articleWrite(avo);
		
		
		
		return "redirect:/articleView.pik?b_seq="+seq;
	}
	
}
