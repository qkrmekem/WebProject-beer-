package kr.controller.pik;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import kr.dao.pik.BeerMapper;
import kr.entity.pik.BEER2;

public class beerListController implements Controller {
	// Servlet ->pojo(프론트컨트롤러가 해야할 일을 대신해주는 클래스) extends없애고 메소드명 service를 바꾸기
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		  BeerMapper dao = new BeerMapper(); 
		  List<BEER2> list = dao.newAll();
		 

		/*
		 String name = request.getParameter("name"); int from_seq =
		 Integer.parseInt(request.getParameter("from_seq")); int AROMA_SEQ =
		 Integer.parseInt(request.getParameter("AROMA_SEQ")); String COUNTRY_CD =
		 request.getParameter("COUNTRY_CD"); int TASTE_SEQ =
		 Integer.parseInt(request.getParameter("TASTE_SEQ")); int TASTE_SEQ2 =
		 Integer.parseInt(request.getParameter("TASTE_SEQ2"));
		 */
		// int TASTE_SEQ3 = Integer.parseInt(request.getParameter("TASTE_SEQ3"));

		/*
		 System.out.println(name + " / " + from_seq + " / " + AROMA_SEQ + " / " +
		 COUNTRY_CD + " / " + TASTE_SEQ + " / " + TASTE_SEQ2 + " / ");
		 */

		
		/*
		 BEER vo = new BEER(); vo.setBEER_NAME(name); vo.setFROM_SEQ(from_seq);
		 vo.setAROMA_SEQ(AROMA_SEQ); vo.setCOUNTRY_CD(COUNTRY_CD);
		 vo.setTASTE_SEQ(TASTE_SEQ); vo.setTASTE_SEQ2(TASTE_SEQ2);
		 vo.setTASTE_SEQ3(TASTE_SEQ3); BeerMapper dao = new BeerMapper(); List<BEER>
		 list = dao.newAll(vo);
		 */
		 
		 System.out.println("beerListController : " + list.size() + list);
		 
		
		 Gson gson = new Gson();
		 
		 String json=gson.toJson(list);
		 response.setContentType("text/json;charset=utf-8"); PrintWriter out =
		 response.getWriter(); 
		 out.println(json); // data만 callback함수로 보내기
		 

		return null;
	}
}
