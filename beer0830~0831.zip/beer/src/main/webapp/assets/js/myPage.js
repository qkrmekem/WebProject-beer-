function editNickName(){

    //혹시 열린 창 닫기
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");
    
    //수정 부분 열기
    $(".boxBasic-nic-pik").css("display","none");
    $(".boxEdit-nic-pik").css("display","block");

}
function editEmail(){
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");

    $(".boxBasic-email-pik").css("display","none");
    $(".boxEdit-email-pik").css("display","block");
}
function editPassword(){
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");

    $(".boxBasic-pw-pik").css("display","none");
    $(".boxEdit-pw-pik").css("display","block");
}
function editBirthdate(){
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");

    $(".boxBasic-birth-pik").css("display","none");
    $(".boxEdit-birth-pik").css("display","block");
}
function editClose(){
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");
}