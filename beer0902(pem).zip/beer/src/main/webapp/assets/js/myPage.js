function editNickName(){

    //혹시 열린 창 닫기
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");
    
    //수정 부분 열기
    $(".boxBasic-nic-pik").css("display","none");
    $(".boxEdit-nic-pik").css("display","block");

}
function editEmail(){
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");

    $(".boxBasic-email-pik").css("display","none");
    $(".boxEdit-email-pik").css("display","block");
}
function editPassword(){
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");

    $(".boxBasic-pw-pik").css("display","none");
    $(".boxEdit-pw-pik").css("display","block");
}
function editBirthdate(){
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");

    $(".boxBasic-birth-pik").css("display","none");
    $(".boxEdit-birth-pik").css("display","block");
}
function editClose(){
    $(".boxBasic-pik").css("display","block");
    $(".boxEdit-pik").css("display","none");
}

function updateNickName(cpath) {
	
	var m_nickname = $("#m_nickname").val();
	
	$.ajax({
	
		url :`${cpath}/myPageEdit.pik`,
		type :"post",
		data :{"update":"nickname","m_nickname":m_nickname},
		success : function(){
			$("#nickname").text( m_nickname);
			editClose();
		},
		error :function(){alert("error")}
	});
}

function updateEmail(cpath) {
	
	var m_email = $("#m_email").val();
	
	$.ajax({
		url :`${cpath}/myPageEdit.pik`,
		type :"post",
		data :{"update":"email","m_email":m_email},
		success : function(){
			$("#email").text(m_email);
			editClose();
		},
		error : function(){alert("error")}
	});
}

function updatePassword(cpath,m_pw) {
	var pw = `${m_pw}`;
	var pre_pw = $("#pre_pw").val();
	var new_pw = $("#new_pw").val();
	var check_pw = $("#check_pw").val();
	
	if(pw == pre_pw){
		$("#wrong-new-pw").css("display","none");
		$("#wrong-pw").css("display","none");
		
		if(new_pw == check_pw){
		
			$.ajax({
				url :`${cpath}/myPageEdit.pik`,
				type :"post",
				data :{"update":"pw","new_pw":new_pw},
				success : function(){
					$("#pre_pw").val("");
					$("#new_pw").val("");
					$("#check_pw").val("");		
					editClose()
				},
				error : function(){alert("error")}
			});
		}else{
			$("#wrong-new-pw").css("display","block");
		}
	}else{
		$("#wrong-pw").css("display","block");
	}
	
	
}
function updateBirthdate(cpath) {
	
	var m_birthdate = $("#m_birthdate").val();
	
	$.ajax({
		url :`${cpath}/myPageEdit.pik`,
		type :"post",
		data :{"update":"birth","m_birthdate":m_birthdate},
		success :function(){
			$("#birthdate").text(m_birthdate);
			editClose();
		},
		error :function(){alert("error")}
	});
}
/*
function updateFavorite(cpath) {
	
	var  = $("").val();
	
	$.ajax({
		url :`${cpath}/myPageEdit.pik`,
		type :"post",
		data :{"update":"favorite","m_birthdate":m_birthdate},
		success :function(){
			$("#birthdate").text(m_birthdate);
			editClose();
		},
		error :function(){alert("error")}
	});
}

*/
