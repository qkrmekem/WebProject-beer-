package kr.dao.pik;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import kr.entity.pik.Member;

public class MemberMapper {
	
	private static SqlSessionFactory sqlSessionFactory = null;
	
	static {
		try {
			String resource = "/kr/dao/pik/mybatis-config.xml";
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public int register (Member member) {
		 SqlSession session = sqlSessionFactory.openSession();
		 int cnt =0;
		 try {
			 cnt= session.insert("register",member);
		 }catch (Exception e) {
			 e.printStackTrace();
			 
		 }
		 session.commit();
		 session.close();
		 return cnt;
	}
	public Member logIn(Member vo) {
		SqlSession session = sqlSessionFactory.openSession();
		Member mvo = null;
		 try {
			mvo = session.selectOne("logIn",vo);
			 session.close();
		 }catch (Exception e) {
			 e.printStackTrace();
		 }
		 return mvo;
	}
//	public Member logIn(String m_id) {
//		SqlSession session = sqlSessionFactory.openSession();
//		 Member vo = null;
//		 try {
//			 vo = session.selectOne("logIn",m_id);
//			 session.close();
//		 }catch (Exception e) {
//			 e.printStackTrace();
//		 }
//		 return vo;
//	}
}
