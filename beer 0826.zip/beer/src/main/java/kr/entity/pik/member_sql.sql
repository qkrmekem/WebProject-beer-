create table member(
    idnum number not null primary key,
    id varchar2(20) not null unique,
    password varchar2(20) not null,
    name varchar2(10) not null,
    birthdate date not null,
    gender number not null,
    email varchar2(30) not null
);

create sequence member_idnum;
