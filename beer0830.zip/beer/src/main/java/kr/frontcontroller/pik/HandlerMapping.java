 package kr.frontcontroller.pik;

import java.util.HashMap;

import kr.controller.pik.ArticleDeleteController;
import kr.controller.pik.ArticleListController;
import kr.controller.pik.ArticleUpdateController;
import kr.controller.pik.ArticleUpdateFormController;
import kr.controller.pik.ArticleViewController;
import kr.controller.pik.ArticleWriteController;
import kr.controller.pik.ArticleWriteFormController;
import kr.controller.pik.Controller;
import kr.controller.pik.DoubleCheckController;
import kr.controller.pik.IndexController;
import kr.controller.pik.LogInFormController;
import kr.controller.pik.LoginController;
import kr.controller.pik.LogoutController;
import kr.controller.pik.MyPageController;
import kr.controller.pik.RegisterController;
import kr.controller.pik.RegisterFormController;
import kr.controller.pik.beerListController;
import kr.controller.pik.beerRecommendController;
import kr.controller.pik.beerSearchFormController;
import kr.controller.pik.beerViewListController;

public class HandlerMapping {
	
	private HashMap<String , Controller> mappings;
	
	public HandlerMapping() {
		mappings = new HashMap<String , Controller>();
		mappings.put("/index.pik", new IndexController());
		// beer관련 
		mappings.put("/beerRecommend.pik", new beerRecommendController());
		mappings.put("/beerList.pik", new beerListController());
		mappings.put("/beerSearchForm.pik", new beerSearchFormController());
		mappings.put("/beerViewList.pik", new beerViewListController());
		
		// 게시판관련
		mappings.put("/articleView.pik", new ArticleViewController());
		mappings.put("/articleUpdate.pik", new ArticleUpdateController());
		mappings.put("/articleUpdateForm.pik", new ArticleUpdateFormController());
		mappings.put("/articleList.pik", new ArticleListController());
		mappings.put("/articleWriteForm.pik", new ArticleWriteFormController());
		mappings.put("/articleWrite.pik", new ArticleWriteController());
		mappings.put("/articleDelete.pik", new ArticleDeleteController());
		
		// 로그인관련
		mappings.put("/login.pik", new LoginController());
		mappings.put("/loginForm.pik", new LogInFormController());
		mappings.put("/logout.pik", new LogoutController());
		
		// 회원정보관련
		mappings.put("/myPage.pik", new MyPageController());
		mappings.put("/registerForm.pik", new RegisterFormController());
		mappings.put("/register.pik", new RegisterController());
		mappings.put("/doubleCheck.pik", new DoubleCheckController());
	}
	
	public Controller getController (String command) {
		return mappings.get(command);
	}
	

}
