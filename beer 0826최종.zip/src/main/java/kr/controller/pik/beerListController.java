package kr.controller.pik;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import kr.dao.pik.BeerMapper;
import kr.entity.pik.Beer;

public class beerListController implements Controller{
	//Servlet ->pojo(프론트컨트롤러가 해야할 일을 대신해주는 클래스) extends없애고 메소드명 service를 바꾸기 
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		BeerMapper dao = new BeerMapper();
		List<Beer> list = dao.allList();		
		
		Gson gson = new Gson();
		
		String json=gson.toJson(list);
		response.setContentType("text/json;charset=utf-8");
		PrintWriter out = response.getWriter();
		out.println(json); // data만 callback함수로 보내기
		
		return null;
	}
}
