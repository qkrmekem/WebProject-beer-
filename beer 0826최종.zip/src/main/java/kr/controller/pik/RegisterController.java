package kr.controller.pik;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.dao.pik.MemberMapper;
import kr.entity.pik.Member;

public class RegisterController implements Controller {

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		
		String m_id = request.getParameter("m_id");
		String m_pw =request.getParameter("m_pw");
		String m_name=request.getParameter("m_name");
		String year=request.getParameter("yy");
		String month=request.getParameter("mm");
		String day=request.getParameter("dd");
		char m_gender = request.getParameter("m_gender").charAt(0);
		String m_email=request.getParameter("email");
		String m_birthdate = year+"-"+month+"-"+day;
		// 회원가입 시 회원타입 기본값 normal 
		char m_type ='n';
		
		Member member = new Member(m_id, m_pw, m_name, m_birthdate, m_gender, m_email, m_type);
		
		
		MemberMapper dao = new MemberMapper();
		int cnt = dao.register(member);
		
		if(cnt>0) {
			return "main";
		}else {
			return "register";
		}
	}

}

