package kr.entity.pik;

public class Beer {
	
	private int b_num;
	private String b_name;
	private String b_score;
	private String b_aroma;
	private String b_taste;
	private String b_finish;
	private String b_category;
	private String b_ml;
	private String b_abv;
	private String b_country;
	private String b_src;
	
	public Beer() {
		super();		
	}

	public Beer(String b_name, String b_aroma, String b_taste, String b_finish) {				
		this.b_name = b_name;		
		this.b_aroma = b_aroma;
		this.b_taste = b_taste;
		this.b_finish = b_finish;		
	}
	
	public Beer(int b_num, String b_name, String b_score, String b_aroma, String b_taste, String b_finish,
			String b_category, String b_ml, String b_abv, String b_country, String b_src) {
		super();
		this.b_num = b_num;
		this.b_name = b_name;
		this.b_score = b_score;
		this.b_aroma = b_aroma;
		this.b_taste = b_taste;
		this.b_finish = b_finish;
		this.b_category = b_category;
		this.b_ml = b_ml;
		this.b_abv = b_abv;
		this.b_country = b_country;
		this.b_src = b_src;
	}

	@Override
	public String toString() {
		return "Beer [b_num=" + b_num + ", b_name=" + b_name + ", b_score=" + b_score + ", b_aroma=" + b_aroma
				+ ", b_taste=" + b_taste + ", b_finish=" + b_finish + ", b_category=" + b_category + ", b_ml=" + b_ml
				+ ", b_abv=" + b_abv + ", b_country=" + b_country + ", b_src=" + b_src + "]";
	}

	public int getB_num() {
		return b_num;
	}

	public void setB_num(int b_num) {
		this.b_num = b_num;
	}

	public String getB_name() {
		return b_name;
	}

	public void setB_name(String b_name) {
		this.b_name = b_name;
	}

	public String getB_score() {
		return b_score;
	}

	public void setB_score(String b_score) {
		this.b_score = b_score;
	}

	public String getB_aroma() {
		return b_aroma;
	}

	public void setB_aroma(String b_aroma) {
		this.b_aroma = b_aroma;
	}

	public String getB_taste() {
		return b_taste;
	}

	public void setB_taste(String b_taste) {
		this.b_taste = b_taste;
	}

	public String getB_finish() {
		return b_finish;
	}

	public void setB_finish(String b_finish) {
		this.b_finish = b_finish;
	}

	public String getB_category() {
		return b_category;
	}

	public void setB_category(String b_category) {
		this.b_category = b_category;
	}

	public String getB_ml() {
		return b_ml;
	}

	public void setB_ml(String b_ml) {
		this.b_ml = b_ml;
	}

	public String getB_abv() {
		return b_abv;
	}

	public void setB_abv(String b_abv) {
		this.b_abv = b_abv;
	}

	public String getB_country() {
		return b_country;
	}

	public void setB_country(String b_country) {
		this.b_country = b_country;
	}

	public String getB_src() {
		return b_src;
	}

	public void setB_src(String b_src) {
		this.b_src = b_src;
	}
	
	
	
}
