package kr.controller.pik;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.dao.pik.ArticleMapper;
import kr.entity.pik.Article;

public class ArticleUpdateController implements Controller{

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArticleMapper dao =new ArticleMapper();
		int b_seq = Integer.parseInt(request.getParameter("b_seq"));
		String b_title = request.getParameter("b_title");
		String b_content = request.getParameter("b_content");
		Article vo = new Article();
		vo.setB_seq(b_seq);
		vo.setB_title(b_title);
		vo.setB_content(b_content);
		dao.articleUpdate(vo);
		
		return "redirect:/articleView.pik?b_seq="+b_seq;
	}

}
