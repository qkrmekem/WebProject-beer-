package kr.controller.pik;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.dao.pik.MemberMapper;
import kr.entity.pik.Member;

public class MyPageEditController implements Controller {

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String update = request.getParameter("update");
		HttpSession session = request.getSession();
		Member vo = (Member)session.getAttribute("mvo");
		MemberMapper dao = new MemberMapper();
		
		
		if(update.equals("nickname")) {
				
			String m_nickname = request.getParameter("m_nickname");
			vo.setM_nickname(m_nickname);		
			
			int cnt = dao.updateNickName(vo);
			if(cnt>0) {
				System.out.println("성공!!");
			}
			
		}else if(update.equals("email")){
			
			String m_email = request.getParameter("m_email");
			vo.setM_email(m_email);
			
			int cnt = dao.updateEmail(vo);
			if(cnt>0) {
				System.out.println("성공!!");
			}
			
			
		}else if(update.equals("pw")){
			
			String new_pw = request.getParameter("new_pw");
			vo.setM_pw(new_pw);
			
			int cnt = dao.updatePassword(vo);		
			if(cnt>0) {
				System.out.println("성공!!");
			}
							
		}else if(update.equals("birth")){
			
			String m_birthdate = request.getParameter("m_birthdate");
			vo.setM_birthdate(m_birthdate);
			
			int cnt = dao.updateBirthdate(vo);	
			if(cnt>0) {
				System.out.println("성공!!");
			}
		}
		
		
		return null;
	}

}
