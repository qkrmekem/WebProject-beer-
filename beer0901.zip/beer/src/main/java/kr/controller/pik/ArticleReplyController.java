package kr.controller.pik;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import kr.dao.pik.ArticleMapper;
import kr.entity.pik.Reply;

public class ArticleReplyController implements Controller{

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("댓글콘트롤러까지 옴");
		String reply = request.getParameter("reply");
		ArticleMapper dao = new ArticleMapper();
		System.out.println(reply);
		
		
		if(reply.equals("delete")) {
			int r_seq = Integer.parseInt(request.getParameter("r_seq"));
			System.out.println(r_seq);
			int cnt = dao.replyDelete(r_seq);
			
			if(cnt>0) {
				System.out.println("댓글삭제 완료");
			}
			
		}else if(reply.equals("write")) {
			int b_seq = Integer.parseInt(request.getParameter("b_seq"));
			String m_id = request.getParameter("m_id");
			String r_re = request.getParameter("r_re");
			System.out.println("쓴 댓글 받아오기");
			Reply rvo = new Reply(b_seq, m_id, r_re);
			dao.replyWrite(rvo);
			
			Reply rvo1 = dao.replyWriteView(m_id);
			
			System.out.println("등록할 댓글");
			System.out.println(rvo1.getR_re());
			Gson gson = new Gson();
			String json=gson.toJson(rvo1);
			response.setContentType("text/json;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println(json);
			
			System.out.println("댓글저장 완료");
			
			
			
		}
		
		return null;
	}

}
