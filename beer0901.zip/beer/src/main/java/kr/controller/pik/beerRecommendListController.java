package kr.controller.pik;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import kr.dao.pik.BeerMapper;
import kr.entity.pik.BEER2;
import kr.entity.pik.Member;
import kr.entity.pik.MemberFavorite;

public class beerRecommendListController implements Controller {
	// Servlet ->pojo(프론트컨트롤러가 해야할 일을 대신해주는 클래스) extends없애고 메소드명 service를 바꾸기
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 List<BEER2> list;
		 HttpSession session = request.getSession();
		 Member mvo = (Member)session.getAttribute("mvo");
		 
		 if (mvo != null) {
			 String m_id = mvo.getM_id();
			 BeerMapper dao = new BeerMapper(); 
			 List<MemberFavorite> m_list = dao.getfavor(m_id);		
			 
			 MemberFavorite vo = new MemberFavorite(
					 m_list.get(0).getM_id(),
					 m_list.get(0).getTaste_seq(),
					 m_list.get(0).getAroma_seq(),					 
					 m_list.get(0).getFrom_seq()					 
					 );
			 list = dao.recommendList(vo);			
		 } else {
			 BeerMapper dao = new BeerMapper(); 
			 list = dao.allList();
		 }
		 		 
		 Gson gson = new Gson();		 
		 String json=gson.toJson(list);
		 response.setContentType("text/json;charset=utf-8"); 
		 PrintWriter out = response.getWriter(); 
		 out.println(json); 		 

		return null;
	}
}
