 package kr.frontcontroller.pik;

import java.util.HashMap;

import kr.controller.pik.ArticleListController;
import kr.controller.pik.ArticleUpdateController;
import kr.controller.pik.ArticleViewController;
import kr.controller.pik.ArticleWriteController;
import kr.controller.pik.ArticleWriteFormController;
import kr.controller.pik.Controller;
import kr.controller.pik.IndexController;
import kr.controller.pik.LoginController;
import kr.controller.pik.beerListController;
import kr.controller.pik.beerRecommendController;
import kr.controller.pik.beerSearchFormController;
import kr.controller.pik.beerViewListController;

public class HandlerMapping {
	
	private HashMap<String , Controller> mappings;
	
	public HandlerMapping() {
		mappings = new HashMap<String , Controller>();
		mappings.put("/index.pik", new IndexController());
		mappings.put("/beerRecommend.pik", new beerRecommendController());
		mappings.put("/beerList.pik", new beerListController());
		mappings.put("/beerSearchForm.pik", new beerSearchFormController());
		mappings.put("/beerViewList.pik", new beerViewListController());
		mappings.put("/articleView.pik", new ArticleViewController());
		mappings.put("/articleUpdate.pik", new ArticleUpdateController());
		mappings.put("/articleList.pik", new ArticleListController());
		mappings.put("/articleWriteForm.pik", new ArticleWriteFormController());
		mappings.put("/articleWrite.pik", new ArticleWriteController());
		mappings.put("/login.pik", new LoginController());
	}
	
	public Controller getController (String command) {
		return mappings.get(command);
	}
	

}
