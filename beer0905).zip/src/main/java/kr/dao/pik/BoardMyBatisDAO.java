package kr.dao.pik;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

// MyBatis Framework : Java <--SQL Mapping--> SQL(XML파일)
// MyBatis => SQL Mapping Framework
// http://mybatis.org
// https://blog.mybatis.org/
public class BoardMyBatisDAO {
	private static SqlSessionFactory sqlSessionFactory;
	//초기화 블럭(프로그램 실행시 딱 한번만 실행이 되는 블럭)
	
	static {
		try {
			String resource = "kr/board/dao/mybatis-config.xml";
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory =
			  new SqlSessionFactoryBuilder().build(inputStream);
			//
		} catch (Exception e) {
			e.printStackTrace();
		}
		//게시판 전체리스트 가져오기 메서드
	}
	
}
