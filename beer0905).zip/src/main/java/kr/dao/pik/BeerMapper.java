package kr.dao.pik;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import kr.entity.pik.Beer;
import kr.entity.pik.Member;

// MyBatis Framework : Java <--SQL Mapping--> SQL(XML파일)
// MyBatis => SQL Mapping Framework
// http://mybatis.org
// https://blog.mybatis.org/
public class BeerMapper {
	private static SqlSessionFactory sqlSessionFactory;
	//초기화 블럭(프로그램 실행시 딱 한번만 실행이 되는 블럭)
	
	static {
		try {
			String resource = "kr/dao/pik/mybatis-config.xml";
			InputStream inputStream = Resources.getResourceAsStream(resource);
			sqlSessionFactory =
			  new SqlSessionFactoryBuilder().build(inputStream);
			//
		} catch (Exception e) {
			e.printStackTrace();
		}
		//게시판 전체리스트 가져오기 메서드
	}
	
	
	// 게시판 전체 리스트 가져오기 메소드
	public List<Beer> allList() {
		SqlSession session = sqlSessionFactory.openSession();
		List<Beer> list = session.selectList("allList"); // select * from beer order by num
		session.close(); // session 반납 여유 session(connection)이 없을때 가동 안되므로 session.close()가 필요함
		return list;

	}
	
	// 정보 검색한 리스트 가져오기
	public List<Beer> viewList(Beer vo) {
		SqlSession session = sqlSessionFactory.openSession();
		List<Beer> list = session.selectList("viewList", vo);
		session.close();
		return list;

	}
	
}
