package kr.controller.pik;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.dao.pik.ArticleMapper;
import kr.dao.pik.EventMapper;
import kr.entity.pik.Article;
import kr.entity.pik.Event;

public class EventUpdateController implements Controller{

	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EventMapper dao =new EventMapper();
		int b_seq = Integer.parseInt(request.getParameter("b_seq"));
		String b_title = request.getParameter("b_title");
		String b_content = request.getParameter("b_content");
		Event vo = new Event();
		vo.setB_seq(b_seq);
		vo.setB_title(b_title);
		vo.setB_content(b_content);
		dao.eventUpdate(vo);
		
		return "redirect:/eventView.pik?b_seq="+b_seq;
	}

}

