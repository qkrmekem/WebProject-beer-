package kr.controller.pik;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import kr.dao.pik.ArticleMapper;
import kr.dao.pik.EventMapper;
import kr.entity.pik.Article;
import kr.entity.pik.Member;
import kr.entity.pik.Event;
public class EventWriteController implements Controller {
	@Override
	public String requestProcessor(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset = UTF-8");
		PrintWriter out = response.getWriter();
		String savePath = "upload";
		int uploadFileSizeLimit = 5*1024*1024;
		String encType = "UTF-8";
		ServletContext context = getServletContext();
		String uploadFilePath = context.getRealPath(savePath);
		try {
			MultipartRequest multi = new MultipartRequest();
			request,
			uploadFilePath,
			uploadFileSizeLimit,
			encType,
			new DefaultFileRenamePolicy());
			String fileName = multi.getFilesystemName(uploadFilePath)
		}*/
		request.setCharacterEncoding("UTF-8");
		ServletContext context = request.getSession().getServletContext();
		String path = context.getRealPath("upload");
		String encType = "UTF-8";
		int sizeLimit = 20*1024*1024;
		MultipartRequest multi = new MultipartRequest(request,path,sizeLimit, 
						encType,new DefaultFileRenamePolicy());
		System.out.println(path);
		HttpSession session = request.getSession();
		Member mvo = (Member)session.getAttribute("mvo");
		String b_title = multi.getParameter("b_title");
		String b_content = multi.getParameter("b_content");
		String b_file=multi.getFilesystemName("b_file");
		String m_id=mvo.getM_id();
		
		System.out.println(mvo.getM_id());
		
		Event nvo = new Event(b_title, b_content, b_file, m_id);
		nvo.setB_seq(0);
		
		System.out.println(nvo.toString());
		
		EventMapper dao = new EventMapper();
		
		int seq = dao.eventWrite(nvo);
		
		return "redirect:/eventView.pik?b_seq="+seq;
	}
}